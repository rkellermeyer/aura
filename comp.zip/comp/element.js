import {inject} from 'aurelia-dependency-injection';
import {customElement, bindable, ElementEvents} from 'aurelia-templating';
import {DOM} from 'aurelia-pal';

@customElement('white-board')
@inject(DOM.Element, ElementEvents)
export class WhiteBaord {

  @bindable value = null;

  /**
   *   Container's Element event instance
   */
  events:ElementEvents;

  /**
   *   The viewModel's HTML Element
   */
  element:HTMLElement;

  constructor(element, events) {
    this.element = element;
    this.events = events;
  }

  created(parentView:View, view:View):void {}

  bind(bindingContext:Object, overrideContext:Object):void {}

  attached():void {}

  detached():void {}

  unbind():void {}
}
